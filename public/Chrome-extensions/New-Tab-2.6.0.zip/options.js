const DEFAULT_SETTINGS = BlackThemeStore.defaults;
const list = document.querySelector('#social-list');
const template = document.querySelector('#social-template');
const nameInput = document.querySelector('#display-name');
const socialsToggle = document.querySelector('#socials-enabled');
const widgetControls = [...document.querySelectorAll('[data-widget-control]')];
const colorControls = [...document.querySelectorAll('[data-color-control]')];
const wallpaperPreview = document.querySelector('#wallpaper-preview');
const wallpaperVideoPreview = document.querySelector('#wallpaper-video-preview');
const wallpaperUrl = document.querySelector('#wallpaper-url');
const wallpaperUpload = document.querySelector('#wallpaper-upload');
const wallpaperName = document.querySelector('#wallpaper-name');
const statusElement = document.querySelector('#status');
let settings = BlackThemeStore.clone(DEFAULT_SETTINGS);
let pendingVideoKey = '';

const POSITION_LABELS = {
    'top-left':'Top left', 'top-center':'Top center', 'top-right':'Top right',
    'center-left':'Center left', center:'Center', 'center-right':'Center right',
    'bottom-left':'Bottom left', 'bottom-center':'Bottom center', 'bottom-right':'Bottom right'
};

for (const control of widgetControls) {
    const select = control.querySelector('[data-widget-field="position"]');
    for (const [value, label] of Object.entries(POSITION_LABELS)) select.add(new Option(label, value));
}

function setStatus(message, type = '') { statusElement.textContent = message; statusElement.className = type; }
const validHex = (value) => /^#[0-9a-f]{6}$/i.test(value);

async function fileToImageData(file, icon = false) {
    const bitmap = await createImageBitmap(file);
    const limit = icon ? 256 : 2560;
    const scale = Math.min(1, limit / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    canvas.getContext('2d', { alpha: icon }).drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close?.();
    return canvas.toDataURL(icon ? 'image/png' : 'image/webp', icon ? undefined : .9);
}

function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(file);
    });
}

async function fileToWallpaper(file) {
    const isVideo = file.type.startsWith('video/');
    const isGif = file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif');
    if (isVideo) return { name:file.name, src:'', blobKey:await BlackThemeStore.putMedia(file), type:'video', packaged:false };
    if (isGif) return { name:file.name, src:await readFileAsDataUrl(file), type:'image', packaged:false };
    return { name:file.name, src:await fileToImageData(file), type:'image', packaged:false };
}

function iconMarkup(icon, name) {
    const icons = {
        gmail: '<svg viewBox="0 0 24 24"><path d="M3.5 5h17A2.5 2.5 0 0 1 23 7.5v9a2.5 2.5 0 0 1-2.5 2.5h-17A2.5 2.5 0 0 1 1 16.5v-9A2.5 2.5 0 0 1 3.5 5Zm.2 2 8.3 6.2L20.3 7H3.7Zm17.3 2.1-8.4 6.3a1 1 0 0 1-1.2 0L3 9.1v7.4c0 .3.2.5.5.5h17c.3 0 .5-.2.5-.5V9.1Z"/></svg>',
        github: '<svg viewBox="0 0 24 24"><path d="M12 .8a11.4 11.4 0 0 0-3.6 22.2c.6.1.8-.2.8-.6v-2.2c-3.3.7-4-1.4-4-1.4-.5-1.4-1.3-1.7-1.3-1.7-1.1-.8.1-.8.1-.8 1.2.1 1.8 1.2 1.8 1.2 1.1 1.9 2.8 1.3 3.5 1 .1-.8.4-1.3.8-1.6-2.7-.3-5.5-1.3-5.5-5.9 0-1.3.5-2.4 1.2-3.2-.1-.3-.5-1.5.1-3.2 0 0 1-.3 3.3 1.2a11.5 11.5 0 0 1 6 0c2.3-1.5 3.3-1.2 3.3-1.2.7 1.7.3 2.9.1 3.2.8.9 1.2 2 1.2 3.2 0 4.6-2.8 5.6-5.5 5.9.4.4.8 1.1.8 2.2v3.3c0 .4.2.7.8.6A11.4 11.4 0 0 0 12 .8Z"/></svg>',
        youtube: '<svg viewBox="0 0 24 24"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8ZM9.6 15.6V8.4l6.3 3.6-6.3 3.6Z"/></svg>',
        rockstar: '<svg viewBox="0 0 24 24"><path d="M4 2h10.1c3.7 0 5.9 2 5.9 5.2 0 2.2-1.1 3.9-3.1 4.7l3.7 6.1H16l-3.1-5.3H8.3V18H4V2Zm4.3 3.6v3.6h5.2c1.3 0 2-.6 2-1.8s-.7-1.8-2-1.8H8.3Z"/><path d="m15.7 14.2 1.1 2.2 2.5.4-1.8 1.8.4 2.5-2.2-1.2-2.2 1.2.4-2.5-1.8-1.8 2.5-.4 1.1-2.2Z"/></svg>',
        globe: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M3.5 12h17M12 3c2.2 2.5 3.3 5.5 3.3 9S14.2 18.5 12 21c-2.2-2.5-3.3-5.5-3.3-9S9.8 5.5 12 3Z" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
        mail: '<svg viewBox="0 0 24 24"><path d="M3 6h18v12H3V6Zm1.5 1.7 7.5 5.6 7.5-5.6" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>',
        star: '<svg viewBox="0 0 24 24"><path d="m12 2.5 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5-5.8-3.1-5.8 3.1 1.1-6.5-4.7-4.6 6.5-.9L12 2.5Z"/></svg>'
    };
    if (icon === 'letter') return `<b>${(name || '?').slice(0, 1).toUpperCase()}</b>`;
    return icons[icon] || icons.globe;
}

function socialImageUrl(social) {
    if (social.iconPackaged && globalThis.chrome?.runtime?.getURL) return chrome.runtime.getURL(social.iconUrl);
    return social.iconUrl;
}

function updatePreview(row, social) {
    const preview = row.querySelector('.icon-preview');
    preview.replaceChildren();
    if (social.icon === 'custom' && social.iconUrl) {
        const image = document.createElement('img'); image.alt = ''; image.src = socialImageUrl(social);
        image.onerror = () => { preview.innerHTML = iconMarkup('globe', social.name); };
        preview.append(image);
    } else preview.innerHTML = iconMarkup(social.icon, social.name);
}

let previewAssetId = '';
let previewAssetUrl = '';
let previewVersion = 0;

async function renderWallpaper() {
    const wallpaper = settings.wallpaper;
    const assetId = wallpaper.blobKey || BlackThemeStore.assetUrl(wallpaper);
    const version = ++previewVersion;
    let wallpaperSource = previewAssetId === assetId ? previewAssetUrl : await BlackThemeStore.resolveAssetUrl(wallpaper);
    if (version !== previewVersion) { if (wallpaperSource !== previewAssetUrl) BlackThemeStore.releaseAssetUrl(wallpaperSource); return; }
    if (previewAssetId !== assetId) {
        BlackThemeStore.releaseAssetUrl(previewAssetUrl);
        previewAssetId = assetId; previewAssetUrl = wallpaperSource;
    }
    const isVideoWallpaper = BlackThemeStore.mediaType(wallpaper) === 'video';
    if (!wallpaperSource) { setStatus('The saved local video is unavailable. Upload it again.', 'error'); return; }
    if (isVideoWallpaper) {
        wallpaperPreview.style.display = 'none';
        wallpaperVideoPreview.style.display = 'block';
        wallpaperVideoPreview.muted = true;
        wallpaperVideoPreview.defaultMuted = true;
        wallpaperVideoPreview.volume = 0;
        if (wallpaperVideoPreview.src !== wallpaperSource) wallpaperVideoPreview.src = wallpaperSource;
        if (!document.hidden) wallpaperVideoPreview.play().catch(() => {});
    } else {
        wallpaperVideoPreview.pause();
        wallpaperVideoPreview.removeAttribute('src');
        wallpaperVideoPreview.load();
        wallpaperVideoPreview.style.display = 'none';
        wallpaperPreview.style.display = 'block';
        wallpaperPreview.src = wallpaperSource;
    }
}

function render() {
    nameInput.value = settings.displayName;
    socialsToggle.checked = settings.socialsEnabled;
    for (const control of widgetControls) {
        const widget = settings.widgets[control.dataset.widgetControl];
        for (const input of control.querySelectorAll('[data-widget-field]')) {
            const field = input.dataset.widgetField;
            if (input.type === 'checkbox') input.checked = widget[field]; else input.value = widget[field];
        }
        control.classList.toggle('disabled', !widget.enabled);
    }
    for (const control of colorControls) {
        const color = settings.appearance[control.dataset.colorControl];
        control.querySelector('[data-color-picker]').value = color;
        const hex = control.querySelector('[data-color-hex]');
        hex.value = color;
        hex.classList.remove('invalid');
    }
    renderWallpaper();
    wallpaperName.textContent = settings.wallpaper.name || 'Wallpaper';
    wallpaperUrl.value = settings.wallpaper.packaged || settings.wallpaper.blobKey || String(settings.wallpaper.src || '').startsWith('data:') ? '' : settings.wallpaper.src;
    list.replaceChildren();
    if (!settings.socials.length) {
        const empty = document.createElement('div'); empty.className = 'empty'; empty.textContent = 'No socials yet. Add one whenever you want.'; list.append(empty); return;
    }
    settings.socials.forEach((social, index) => {
        const row = template.content.firstElementChild.cloneNode(true); row.dataset.index = index; row.classList.toggle('disabled', social.enabled === false);
        row.querySelector('.row-number').textContent = String(index + 1).padStart(2, '0');
        row.querySelector('[data-field="name"]').value = social.name || '';
        row.querySelector('[data-field="url"]').value = social.url || '';
        row.querySelector('[data-field="icon"]').value = social.icon || 'globe';
        const iconUrl = row.querySelector('[data-field="iconUrl"]');
        const locallyHeld = social.iconPackaged || social.iconUrl?.startsWith('data:');
        iconUrl.value = locallyHeld ? '' : (social.iconUrl || ''); iconUrl.disabled = social.icon !== 'custom';
        iconUrl.placeholder = locallyHeld ? 'Local image selected' : 'Paste image URL';
        row.querySelector('.upload-state').textContent = locallyHeld ? (social.iconPackaged ? 'Bundled icon' : 'Uploaded locally') : '';
        row.querySelector('[data-field="enabled"]').checked = social.enabled !== false;
        row.querySelector('[data-action="up"]').disabled = index === 0;
        row.querySelector('[data-action="down"]').disabled = index === settings.socials.length - 1;
        updatePreview(row, social); list.append(row);
    });
}

nameInput.addEventListener('input', () => { settings.displayName = nameInput.value; setStatus('Unsaved changes'); });
socialsToggle.addEventListener('change', () => { settings.socialsEnabled = socialsToggle.checked; setStatus('Unsaved changes'); });
for (const control of widgetControls) {
    control.addEventListener('input', (event) => {
        const field = event.target.dataset.widgetField; if (!field) return;
        const widget = settings.widgets[control.dataset.widgetControl];
        widget[field] = event.target.type === 'checkbox' ? event.target.checked : event.target.type === 'number' ? Number(event.target.value || 0) : event.target.value;
        if (field === 'enabled') control.classList.toggle('disabled', !widget.enabled);
        setStatus('Unsaved changes');
    });
    control.addEventListener('change', (event) => event.target.dispatchEvent(new Event('input', { bubbles:true })));
}
for (const control of colorControls) {
    const picker = control.querySelector('[data-color-picker]');
    const hex = control.querySelector('[data-color-hex]');
    picker.addEventListener('input', () => {
        const color = picker.value.toUpperCase();
        hex.value = color; hex.classList.remove('invalid');
        settings.appearance[control.dataset.colorControl] = color;
        setStatus('Unsaved changes');
    });
    hex.addEventListener('input', () => {
        let color = hex.value.trim();
        if (color && !color.startsWith('#')) color = `#${color}`;
        const valid = validHex(color);
        hex.classList.toggle('invalid', !valid);
        if (valid) {
            color = color.toUpperCase(); picker.value = color;
            settings.appearance[control.dataset.colorControl] = color;
            setStatus('Unsaved changes');
        } else setStatus('Enter a six-digit hex color such as #FFFFFF.', 'error');
    });
    hex.addEventListener('blur', () => { if (validHex(settings.appearance[control.dataset.colorControl])) hex.value = settings.appearance[control.dataset.colorControl]; hex.classList.remove('invalid'); });
}

list.addEventListener('input', (event) => {
    const row = event.target.closest('.social-row'); if (!row || !event.target.dataset.field) return;
    const social = settings.socials[Number(row.dataset.index)]; const field = event.target.dataset.field;
    social[field] = event.target.type === 'checkbox' ? event.target.checked : event.target.value;
    if (field === 'iconUrl') social.iconPackaged = false;
    if (field === 'icon') row.querySelector('[data-field="iconUrl"]').disabled = event.target.value !== 'custom';
    row.classList.toggle('disabled', social.enabled === false); updatePreview(row, social); setStatus('Unsaved changes');
});
list.addEventListener('change', (event) => event.target.dispatchEvent(new Event('input', { bubbles:true })));
list.addEventListener('change', async (event) => {
    if (event.target.dataset.action !== 'upload-icon' || !event.target.files?.[0]) return;
    const social = settings.socials[Number(event.target.closest('.social-row').dataset.index)]; setStatus('Preparing icon…');
    try { social.icon = 'custom'; social.iconUrl = await fileToImageData(event.target.files[0], true); social.iconPackaged = false; render(); setStatus('Icon uploaded — save to apply'); }
    catch (_) { setStatus('That icon could not be read.', 'error'); }
});
list.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-action]'); if (!button) return;
    const index = Number(button.closest('.social-row').dataset.index); const action = button.dataset.action;
    if (action === 'remove') settings.socials.splice(index, 1);
    if (action === 'up' && index > 0) [settings.socials[index - 1], settings.socials[index]] = [settings.socials[index], settings.socials[index - 1]];
    if (action === 'down' && index < settings.socials.length - 1) [settings.socials[index + 1], settings.socials[index]] = [settings.socials[index], settings.socials[index + 1]];
    render(); setStatus('Unsaved changes');
});

document.querySelector('#add-social').addEventListener('click', () => { settings.socials.push({ id:crypto.randomUUID(), name:'New social', url:'https://', icon:'globe', iconUrl:'', enabled:true }); render(); setStatus('Unsaved changes'); list.lastElementChild?.querySelector('[data-field="name"]')?.focus(); });
document.querySelector('#apply-wallpaper-url').addEventListener('click', () => {
    try {
        const value = new URL(wallpaperUrl.value.trim()).href;
        const linked = { name:'Linked background', src:value, packaged:false };
        linked.type = BlackThemeStore.mediaType(linked);
        if (pendingVideoKey) BlackThemeStore.removeMedia(pendingVideoKey);
        pendingVideoKey = '';
        settings.wallpaper = linked;
        render(); setStatus('Background link selected — save to apply');
    }
    catch (_) { setStatus('Enter a valid direct image, GIF or video URL.', 'error'); }
});
wallpaperUpload.addEventListener('change', async () => {
    const file = wallpaperUpload.files?.[0]; if (!file) return; setStatus('Preparing wallpaper…');
    try {
        const wallpaper = await fileToWallpaper(file);
        if (pendingVideoKey && pendingVideoKey !== wallpaper.blobKey) await BlackThemeStore.removeMedia(pendingVideoKey);
        pendingVideoKey = wallpaper.blobKey || '';
        settings.wallpaper = wallpaper; wallpaperUpload.value = ''; render(); setStatus('Background uploaded — save to apply');
    }
    catch (_) { setStatus('That image, GIF or video could not be read.', 'error'); }
});
document.querySelector('#reset-wallpaper').addEventListener('click', () => { if (pendingVideoKey) BlackThemeStore.removeMedia(pendingVideoKey); pendingVideoKey = ''; settings.wallpaper = BlackThemeStore.clone(DEFAULT_SETTINGS.wallpaper); render(); setStatus('Original wallpaper restored — save to apply'); });
document.querySelector('#reset-all').addEventListener('click', () => { if (pendingVideoKey) BlackThemeStore.removeMedia(pendingVideoKey); pendingVideoKey = ''; settings = BlackThemeStore.clone(DEFAULT_SETTINGS); render(); setStatus('Defaults restored — save to apply'); });

document.querySelector('#save').addEventListener('click', async () => {
    if (!settings.displayName.trim()) { setStatus('Enter a display name.', 'error'); return; }
    if (colorControls.some((control) => !validHex(control.querySelector('[data-color-hex]').value.trim()))) { setStatus('Fix the highlighted hex color before saving.', 'error'); return; }
    for (const social of settings.socials) {
        if (!social.name.trim()) { setStatus('Every social needs a name.', 'error'); return; }
        try { new URL(social.url); } catch (_) { setStatus(`Invalid URL for ${social.name}.`, 'error'); return; }
        if (social.icon === 'custom' && social.iconUrl) { try { new URL(social.iconUrl, location.href); } catch (_) { setStatus(`Invalid icon for ${social.name}.`, 'error'); return; } }
    }
    settings = await BlackThemeStore.write(settings); pendingVideoKey = ''; render(); setStatus('Saved — your black theme is updated.', 'success');
});

BlackThemeStore.read().then((stored) => { settings = stored; render(); });
document.addEventListener('visibilitychange', () => {
    if (document.hidden) wallpaperVideoPreview.pause();
    else if (BlackThemeStore.mediaType(settings.wallpaper) === 'video') wallpaperVideoPreview.play().catch(() => {});
});
addEventListener('pagehide', () => { BlackThemeStore.releaseAssetUrl(previewAssetUrl); if (pendingVideoKey) BlackThemeStore.removeMedia(pendingVideoKey); });
