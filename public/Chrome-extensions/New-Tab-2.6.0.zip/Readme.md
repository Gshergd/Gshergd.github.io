# New Tab --- Installation & Customization Guide

A private, customizable Chrome New Tab experience.

This guide is specifically for **New Tab v2.6.0** and explains how to
install the extension manually and customize its appearance, layout,
wallpaper, shortcuts, and greeting.

> No coding knowledge is required.

------------------------------------------------------------------------

## 1. Extract the Extension

The extension is provided as a compressed ZIP file.

### On Windows

1.  Right-click the downloaded `.zip` file.
2.  Click **Extract All...**
3.  Choose where you want to keep the extension.
4.  Click **Extract**.

After extraction, open the folder and make sure it directly contains
files such as:

``` text
manifest.json
index.html
options.html
script.js
style.css
wallpaper.png
```

> **Important:** Keep this extracted folder somewhere permanent. Chrome
> loads the extension directly from this folder, so do not delete or
> move it after installation.

A good location would be:

``` text
Documents/
└── Chrome Extensions/
    └── New Tab/
```

------------------------------------------------------------------------

## 2. Open Chrome Extensions

Open Google Chrome and enter this in the address bar:

``` text
chrome://extensions/
```

Press **Enter**.

------------------------------------------------------------------------

## 3. Enable Developer Mode

On the Extensions page, find **Developer mode** in the top-right corner
and turn it on.

Chrome will now show additional extension controls, including **Load
unpacked**.

------------------------------------------------------------------------

## 4. Install New Tab

1.  Click **Load unpacked**.
2.  Select the extracted **New Tab** folder.
3.  Make sure you select the folder that directly contains
    `manifest.json`.
4.  Click **Select Folder**.

The **New Tab** extension should now appear on your Extensions page.

Open a new tab to see it.

------------------------------------------------------------------------

# Customizing Your New Tab

This extension includes its own settings/control room. You do **not**
need to edit any code to customize it.

## Opening the Settings

Open:

``` text
chrome://extensions/
```

Find **New Tab**, click **Details**, and then open **Extension
options**.

This opens the extension's **Black Theme Settings / Control Room**.

Make your changes and click **Save changes** when finished.

------------------------------------------------------------------------

## Display Name & Greeting

Under **Display Name**, enter the name you want the New Tab page to use.

Your name is used by the time-based greeting shown on the page.

For example:

``` text
Good morning, Alex.
Good afternoon, Alex.
Good evening, Alex.
```

The display name can be up to 40 characters long.

------------------------------------------------------------------------

# Widgets & Layout

You can individually customize the four main widgets:

-   **Search** --- Google search bar
-   **Clock** --- Date and time
-   **Greeting** --- Time-based welcome message
-   **Daily Focus** --- Your main focus for the day

Each widget can be independently shown, hidden, moved, and fine-tuned.

## Show or Hide a Widget

Use the switch on each widget card to enable or disable it.

For example, if you want a minimal page containing only the clock, you
can disable Search, Greeting, and Daily Focus.

## Widget Positions

Each widget can be placed in one of nine areas:

``` text
Top Left       Top Center       Top Right

Center Left    Center           Center Right

Bottom Left    Bottom Center    Bottom Right
```

Choose the desired position from the **Position** menu.

## Fine-Tuning with X and Y Offsets

After selecting a general position, you can move the widget more
precisely using its offsets.

### X Offset

Controls horizontal movement.

``` text
Positive X = Move Right
Negative X = Move Left
```

Examples:

``` text
X: 50     → 50 pixels to the right
X: -50    → 50 pixels to the left
X: 0      → No additional horizontal movement
```

### Y Offset

Controls vertical movement.

``` text
Positive Y = Move Down
Negative Y = Move Up
```

Examples:

``` text
Y: 40     → 40 pixels down
Y: -40    → 40 pixels up
Y: 0      → No additional vertical movement
```

This allows you to position every part of the page exactly where you
want it.

------------------------------------------------------------------------

# Colors & Appearance

The extension allows you to recolor the major parts of the New Tab page.

You can use the visual color picker or manually enter a six-digit HEX
color.

Example:

``` text
#FFFFFF
#000000
#C7C7C7
#FF0000
```

## Text

Changes the color used by the greeting, Daily Focus, and other labels.

## Clock

Changes the color of the:

-   Time
-   AM/PM period
-   Date

## Icon Background

Changes the background color of the circular social shortcut buttons.

## Icon Foreground

Changes the color of shortcut symbols and letters.

## Search Bar

Changes the background color of the Google search field.

## Search Text

Changes the color of text you type into the search bar.

## Search Placeholder

Changes the color of the hint/placeholder text shown before you start
typing.

### Creating a Completely Different Look

You are not limited to the original black theme.

For example, you can combine:

``` text
Wallpaper: Your own image/video
Text: #FFFFFF
Clock: #FFFFFF
Icon Background: #FFFFFF
Icon Foreground: #000000
Search Bar: #FFFFFF
Search Text: #000000
Search Placeholder: #666666
```

Experiment with the wallpaper and colors together to create your own
theme.

------------------------------------------------------------------------

# Wallpaper & Background Media

The background can be completely replaced.

The extension supports:

-   Images
-   Animated GIFs
-   Videos
-   Direct media URLs
-   Media uploaded directly from your computer

## Upload a Wallpaper

In **Background / Media → Wallpaper**:

1.  Click **Upload media**.
2.  Select an image, GIF, or video from your computer.
3.  Check the preview.
4.  Click **Save changes**.

Uploaded media is stored by the extension, so you do not need to keep
the original media file in the extension folder.

## Use a Wallpaper URL

You can also use media hosted online.

Paste a direct image, GIF, or video URL into:

**Image, GIF or video URL**

Then click:

**Use URL**

Finally, click **Save changes**.

> The URL should point directly to usable media. If the website blocks
> external loading or the URL later stops working, the wallpaper may
> stop appearing.

## Video Wallpapers

Videos are automatically used as muted, looping backgrounds.

For the smoothest experience, use a reasonably sized and compressed
video rather than an unnecessarily huge file.

## Restore the Original Wallpaper

Click:

**Use original**

Then save your changes.

This restores the extension's original black wallpaper.

------------------------------------------------------------------------

# Social Dock & Shortcuts

The shortcut dock is fully customizable.

You can:

-   Show or hide the entire dock
-   Rename shortcuts
-   Change destination URLs
-   Enable or disable individual shortcuts
-   Change icons
-   Upload custom icons
-   Add new shortcuts
-   Remove shortcuts
-   Reorder shortcuts

## Hide the Entire Social Dock

At the top of Settings, disable:

**Social dock**

This hides every shortcut without requiring you to delete them.

Enable it again whenever you want them back.

------------------------------------------------------------------------

## Edit a Shortcut

Every shortcut contains:

### Name

The name of the shortcut.

Example:

``` text
YouTube
GitHub
Gmail
My Website
```

### Destination URL

The website that opens when the shortcut is clicked.

Example:

``` text
https://www.youtube.com/
```

### Icon

You can choose from the built-in icon types:

-   Gmail
-   GitHub
-   YouTube
-   Rockstar
-   Globe
-   Mail
-   Star
-   First letter
-   Custom image / upload

### First Letter

Selecting **First letter** creates a simple shortcut icon based on the
shortcut's name.

This is useful when you do not have a custom logo.

### Custom Icon

Select:

**Custom image / upload**

You can then either:

-   Paste an image URL, or
-   Upload an image from your computer.

This lets you create shortcuts for practically any website while keeping
its proper logo.

------------------------------------------------------------------------

## Add a New Shortcut

Click:

**+ Add social**

Then configure its:

1.  Name
2.  Destination URL
3.  Icon
4.  Enabled/disabled state

Click **Save changes** when finished.

------------------------------------------------------------------------

## Reorder Shortcuts

Each shortcut has arrow controls:

``` text
↑   Move up
↓   Move down
```

Use these to change the order in which shortcuts appear on your New Tab
page.

------------------------------------------------------------------------

## Remove a Shortcut

Click the:

``` text
×
```

button beside the shortcut you want to remove.

Then save your changes.

------------------------------------------------------------------------

# Saving Changes

After changing your settings, click:

**Save changes**

Open a new tab to see the updated design.

If you already have a New Tab page open, refresh it.

------------------------------------------------------------------------

# Reset Everything

If you experiment too much and want to return to the original design,
open Settings and click:

**Reset everything**

This resets the extension's customization back to its defaults.

This includes the original layout, colors, shortcuts, display name, and
wallpaper.

------------------------------------------------------------------------

# Updating the Extension

If you receive a newer version of New Tab, keep in mind that this
extension is manually installed.

After replacing/updating the extension files:

1.  Open:

``` text
chrome://extensions/
```

2.  Find **New Tab**.
3.  Click the **Reload** button.
4.  Open a fresh New Tab.

If the new release comes as an entirely separate folder, you can also
remove the old extension and use **Load unpacked** on the new version.

> Back up anything important before replacing extension files when
> moving between major versions.

------------------------------------------------------------------------

# Troubleshooting

## "Manifest file is missing or unreadable"

You probably selected the wrong folder.

The folder selected through **Load unpacked** must directly contain:

``` text
manifest.json
```

### Wrong

``` text
New Tab/
└── New Tab/
    └── manifest.json
```

If you select the outer folder, Chrome cannot find the manifest.

### Correct

``` text
New Tab/
├── manifest.json
├── index.html
├── options.html
└── ...
```

Select the folder shown above.

------------------------------------------------------------------------

## The New Tab Page Stopped Working After I Moved the Folder

Chrome's unpacked extensions depend on their source folder.

If you move, rename, or delete that folder, Chrome may no longer be able
to load the extension correctly.

Move it back to its original location or reinstall it using **Load
unpacked**.

------------------------------------------------------------------------

## My Changes Are Not Showing

Try:

1.  Make sure you clicked **Save changes**.
2.  Refresh the New Tab page.
3.  Close the old tab and open a new one.
4.  Open `chrome://extensions/` and reload **New Tab** if necessary.

------------------------------------------------------------------------

## My Online Wallpaper Does Not Load

Check that:

-   The URL is correct.
-   The URL directly points to the image/GIF/video.
-   The media is still publicly accessible.
-   The host allows the media to be loaded externally.

You can avoid dependence on an external URL by using **Upload media**
instead.

------------------------------------------------------------------------

# Removing New Tab

To uninstall the extension:

1.  Open:

``` text
chrome://extensions/
```

2.  Find **New Tab**.
3.  Click **Remove**.
4.  Confirm the removal.

Afterwards, you can safely delete the extracted extension folder.

------------------------------------------------------------------------

# Quick Start

``` text
1. Download the ZIP
2. Extract it
3. Open chrome://extensions/
4. Enable Developer mode
5. Click Load unpacked
6. Select the folder containing manifest.json
7. Open a new tab
8. Open Extension options to customize it
9. Customize your name, widgets, colors, wallpaper and shortcuts
10. Save changes
```

------------------------------------------------------------------------

## Important

This is an **unpacked Chrome extension**, meaning it is installed
manually rather than through the Chrome Web Store.

Only install extensions from sources you trust.

Enjoy your new New Tab.
