(function () {
    const STORAGE_KEY = 'luvinskiBlackSettingsV1';
    const MEDIA_DB = 'luvinskiBlackMediaV1';
    const MEDIA_STORE = 'media';
    const defaults = {
        displayName: 'Luvinski',
        clockEnabled: true,
        widgets: {
            search: { enabled:true, position:'top-center', offsetX:0, offsetY:0 },
            clock: { enabled:true, position:'center', offsetX:0, offsetY:-42 },
            greeting: { enabled:true, position:'center', offsetX:0, offsetY:72 },
            focus: { enabled:true, position:'bottom-center', offsetX:0, offsetY:-58 }
        },
        appearance: {
            textColor: '#FFFFFF',
            clockColor: '#FFFFFF',
            iconBackgroundColor: '#000000',
            iconColor: '#C7C7C7',
            searchBackgroundColor: '#000000',
            searchTextColor: '#FFFFFF',
            searchPlaceholderColor: '#666666'
        },
        socialsEnabled: true,
        socials: [
            { id: 'gmail', name: 'Gmail', url: 'https://mail.google.com/', icon: 'gmail', iconUrl: '', enabled: true },
            { id: 'github', name: 'GitHub', url: 'https://gshergd.github.io/', icon: 'github', iconUrl: '', enabled: true },
            { id: 'youtube', name: 'YouTube', url: 'https://www.youtube.com/', icon: 'youtube', iconUrl: '', enabled: true },
            { id: 'rockstar', name: 'Rockstar Games', url: 'https://www.rockstargames.com/VI', icon: 'rockstar', iconUrl: '', enabled: true },
            { id: 'secretary', name: 'The Secretary', url: 'https://thesecretary-status.gt.tc/', icon: 'custom', iconUrl: 'secretary-icon.png', iconPackaged: true, enabled: true }
        ],
        wallpaper: { name: 'Original black wallpaper', src: 'wallpaper.png', type: 'image', packaged: true }
    };

    const clone = (value) => JSON.parse(JSON.stringify(value));

    const positions = new Set(['top-left', 'top-center', 'top-right', 'center-left', 'center', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right']);

    function normalizeWidget(widget, fallback, legacyEnabled) {
        widget = widget && typeof widget === 'object' ? widget : {};
        const number = (candidate, original) => Number.isFinite(Number(candidate)) ? Math.max(-2000, Math.min(2000, Math.round(Number(candidate)))) : original;
        return {
            enabled: widget.enabled === undefined ? legacyEnabled : widget.enabled !== false,
            position: positions.has(widget.position) ? widget.position : fallback.position,
            offsetX: number(widget.offsetX, fallback.offsetX),
            offsetY: number(widget.offsetY, fallback.offsetY)
        };
    }

    function normalizeColor(value, fallback) {
        return typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value.trim()) ? value.trim().toUpperCase() : fallback;
    }

    function normalize(value = {}) {
        const legacyClock = value.clockEnabled !== false;
        const suppliedWidgets = value.widgets && typeof value.widgets === 'object' ? value.widgets : {};
        const widgets = {
            search: normalizeWidget(suppliedWidgets.search, defaults.widgets.search, true),
            clock: normalizeWidget(suppliedWidgets.clock, defaults.widgets.clock, legacyClock),
            greeting: normalizeWidget(suppliedWidgets.greeting, defaults.widgets.greeting, legacyClock),
            focus: normalizeWidget(suppliedWidgets.focus, defaults.widgets.focus, true)
        };
        const suppliedAppearance = value.appearance && typeof value.appearance === 'object' ? value.appearance : {};
        const appearance = Object.fromEntries(Object.entries(defaults.appearance).map(([key, fallback]) => [key, normalizeColor(suppliedAppearance[key], fallback)]));
        return {
            displayName: typeof value.displayName === 'string' && value.displayName.trim() ? value.displayName.trim().slice(0, 40) : defaults.displayName,
            clockEnabled: widgets.clock.enabled,
            widgets,
            appearance,
            socialsEnabled: value.socialsEnabled !== false,
            socials: Array.isArray(value.socials) ? value.socials : clone(defaults.socials),
            wallpaper: value.wallpaper?.src || value.wallpaper?.blobKey ? value.wallpaper : clone(defaults.wallpaper)
        };
    }

    function openMediaDb() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(MEDIA_DB, 1);
            request.onupgradeneeded = () => request.result.createObjectStore(MEDIA_STORE);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async function mediaRequest(mode, action) {
        const db = await openMediaDb();
        return new Promise((resolve, reject) => {
            const transaction = db.transaction(MEDIA_STORE, mode);
            const request = action(transaction.objectStore(MEDIA_STORE));
            let result;
            request.onsuccess = () => { result = request.result; };
            request.onerror = () => reject(request.error);
            transaction.oncomplete = () => { db.close(); resolve(result); };
            transaction.onerror = () => { db.close(); reject(transaction.error); };
        });
    }

    async function putMedia(blob) {
        const key = crypto.randomUUID();
        await mediaRequest('readwrite', (store) => store.put(blob, key));
        return key;
    }

    const getMedia = (key) => mediaRequest('readonly', (store) => store.get(key));
    const removeMedia = (key) => key ? mediaRequest('readwrite', (store) => store.delete(key)).catch(() => {}) : Promise.resolve();

    async function migrateVideoData(settings, persist) {
        const wallpaper = settings.wallpaper;
        if (wallpaper.type !== 'video' || wallpaper.blobKey || !String(wallpaper.src || '').startsWith('data:video/')) return settings;
        try {
            const blob = await (await fetch(wallpaper.src)).blob();
            const blobKey = await putMedia(blob);
            settings.wallpaper = { name:wallpaper.name, type:'video', blobKey, src:'', packaged:false };
            await persist(settings);
        } catch (_) {}
        return settings;
    }

    async function read() {
        const area = globalThis.chrome?.storage?.local;
        if (area) {
            const result = await area.get(STORAGE_KEY);
            const settings = normalize(result[STORAGE_KEY]);
            return migrateVideoData(settings, (migrated) => area.set({ [STORAGE_KEY]:migrated }));
        }
        try {
            const settings = normalize(JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'));
            return migrateVideoData(settings, (migrated) => localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated)));
        }
        catch (_) { return clone(defaults); }
    }

    async function write(value) {
        const normalized = normalize(value);
        const area = globalThis.chrome?.storage?.local;
        let previous;
        if (area) {
            previous = normalize((await area.get(STORAGE_KEY))[STORAGE_KEY]);
            await area.set({ [STORAGE_KEY]: normalized });
        } else {
            try { previous = normalize(JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')); } catch (_) {}
            localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
        }
        if (previous?.wallpaper?.blobKey && previous.wallpaper.blobKey !== normalized.wallpaper.blobKey) await removeMedia(previous.wallpaper.blobKey);
        return normalized;
    }

    function subscribe(callback) {
        if (!globalThis.chrome?.storage?.onChanged) return () => {};
        const listener = (changes, area) => {
            if (area === 'local' && changes[STORAGE_KEY]?.newValue) callback(normalize(changes[STORAGE_KEY].newValue));
        };
        chrome.storage.onChanged.addListener(listener);
        return () => chrome.storage.onChanged.removeListener(listener);
    }

    function assetUrl(asset) {
        if (!asset?.src) return '';
        if (asset.packaged && globalThis.chrome?.runtime?.getURL) return chrome.runtime.getURL(asset.src);
        return asset.src;
    }

    async function resolveAssetUrl(asset) {
        if (!asset?.blobKey) return assetUrl(asset);
        const blob = await getMedia(asset.blobKey);
        return blob ? URL.createObjectURL(blob) : '';
    }

    function releaseAssetUrl(url) {
        if (String(url || '').startsWith('blob:')) URL.revokeObjectURL(url);
    }

    function mediaType(asset) {
        if (asset?.type === 'video') return 'video';
        const source = String(asset?.src || '').split(/[?#]/, 1)[0].toLowerCase();
        if (source.startsWith('data:video/') || /\.(mp4|webm|ogv|ogg|mov|m4v)$/.test(source)) return 'video';
        return 'image';
    }

    globalThis.BlackThemeStore = { STORAGE_KEY, defaults, clone, normalize, read, write, subscribe, assetUrl, resolveAssetUrl, releaseAssetUrl, putMedia, removeMedia, mediaType };
})();
