const timeElement = document.querySelector('#time');
const periodElement = document.querySelector('#period');
const dateElement = document.querySelector('#date');
const greetingElement = document.querySelector('#greeting');
const queryElement = document.querySelector('#query');
const focusElement = document.querySelector('#focus-input');
const savedMessage = document.querySelector('#saved-message');
const wallpaperElement = document.querySelector('.wallpaper');
const wallpaperVideoElement = document.querySelector('#wallpaper-video');
const socialsElement = document.querySelector('#socials');
const settingsEntry = document.querySelector('#settings-entry');
const widgetElements = Object.fromEntries([...document.querySelectorAll('[data-widget]')].map((element) => [element.dataset.widget, element]));

let currentSettings = BlackThemeStore.clone(BlackThemeStore.defaults);
let wallpaperAssetUrl = '';
let wallpaperVersion = 0;
let hiddenReleaseTimer = 0;
let clockTimer = 0;

function iconMarkup(icon, name) {
    const icons = {
        gmail: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 5h17A2.5 2.5 0 0 1 23 7.5v9a2.5 2.5 0 0 1-2.5 2.5h-17A2.5 2.5 0 0 1 1 16.5v-9A2.5 2.5 0 0 1 3.5 5Zm.2 2 8.3 6.2L20.3 7H3.7Zm17.3 2.1-8.4 6.3a1 1 0 0 1-1.2 0L3 9.1v7.4c0 .3.2.5.5.5h17c.3 0 .5-.2.5-.5V9.1Z"/></svg>',
        github: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 .8a11.4 11.4 0 0 0-3.6 22.2c.6.1.8-.2.8-.6v-2.2c-3.3.7-4-1.4-4-1.4-.5-1.4-1.3-1.7-1.3-1.7-1.1-.8.1-.8.1-.8 1.2.1 1.8 1.2 1.8 1.2 1.1 1.9 2.8 1.3 3.5 1 .1-.8.4-1.3.8-1.6-2.7-.3-5.5-1.3-5.5-5.9 0-1.3.5-2.4 1.2-3.2-.1-.3-.5-1.5.1-3.2 0 0 1-.3 3.3 1.2a11.5 11.5 0 0 1 6 0c2.3-1.5 3.3-1.2 3.3-1.2.7 1.7.3 2.9.1 3.2.8.9 1.2 2 1.2 3.2 0 4.6-2.8 5.6-5.5 5.9.4.4.8 1.1.8 2.2v3.3c0 .4.2.7.8.6A11.4 11.4 0 0 0 12 .8Z"/></svg>',
        youtube: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8ZM9.6 15.6V8.4l6.3 3.6-6.3 3.6Z"/></svg>',
        rockstar: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 2h10.1c3.7 0 5.9 2 5.9 5.2 0 2.2-1.1 3.9-3.1 4.7l3.7 6.1H16l-3.1-5.3H8.3V18H4V2Zm4.3 3.6v3.6h5.2c1.3 0 2-.6 2-1.8s-.7-1.8-2-1.8H8.3Z"/><path d="m15.7 14.2 1.1 2.2 2.5.4-1.8 1.8.4 2.5-2.2-1.2-2.2 1.2.4-2.5-1.8-1.8 2.5-.4 1.1-2.2Z"/></svg>',
        globe: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M3.5 12h17M12 3c2.2 2.5 3.3 5.5 3.3 9S14.2 18.5 12 21c-2.2-2.5-3.3-5.5-3.3-9S9.8 5.5 12 3Z" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
        mail: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18v12H3V6Zm1.5 1.7 7.5 5.6 7.5-5.6" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>',
        star: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 2.5 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5-5.8-3.1-5.8 3.1 1.1-6.5-4.7-4.6 6.5-.9L12 2.5Z"/></svg>'
    };
    if (icon === 'letter') return `<b>${(name || '?').slice(0, 1).toUpperCase()}</b>`;
    return icons[icon] || icons.globe;
}

function updateMoment() {
    const now = new Date();
    const hour = now.getHours();
    timeElement.textContent = `${hour % 12 || 12}:${String(now.getMinutes()).padStart(2, '0')}`;
    periodElement.textContent = hour < 12 ? 'AM' : 'PM';
    dateElement.textContent = now.toLocaleDateString([], { weekday:'short', day:'2-digit', month:'short' });
    greetingElement.textContent = `${hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'}, ${currentSettings.displayName}.`;
}

function renderSocials() {
    socialsElement.replaceChildren();
    for (const social of currentSettings.socials) {
        if (social.enabled === false) continue;
        const link = document.createElement('a');
        link.href = social.url;
        link.title = social.name || '';
        link.setAttribute('aria-label', social.name || 'Shortcut');

        if (social.icon === 'custom' && social.iconUrl) {
            const image = document.createElement('img');
            image.alt = '';
            image.src = social.iconPackaged && globalThis.chrome?.runtime?.getURL ? chrome.runtime.getURL(social.iconUrl) : social.iconUrl;
            image.onerror = () => { link.innerHTML = iconMarkup('globe', social.name); };
            link.append(image);
        } else {
            link.innerHTML = iconMarkup(social.icon, social.name);
        }
        socialsElement.append(link);
    }
}

async function applyWallpaper(wallpaper) {
    const version = ++wallpaperVersion;
    const isVideo = BlackThemeStore.mediaType(wallpaper) === 'video';
    const wallpaperUrl = await BlackThemeStore.resolveAssetUrl(wallpaper);
    if (version !== wallpaperVersion) { BlackThemeStore.releaseAssetUrl(wallpaperUrl); return; }
    BlackThemeStore.releaseAssetUrl(wallpaperAssetUrl);
    wallpaperAssetUrl = wallpaperUrl;
    if (!wallpaperUrl) return;
    if (isVideo) {
        wallpaperElement.style.backgroundImage = 'none';
        wallpaperVideoElement.style.display = 'block';
        wallpaperVideoElement.muted = true;
        wallpaperVideoElement.defaultMuted = true;
        wallpaperVideoElement.volume = 0;
        wallpaperVideoElement.preload = 'auto';
        wallpaperVideoElement.src = wallpaperUrl;
        if (!document.hidden) wallpaperVideoElement.play().catch(() => {});
    } else {
        wallpaperVideoElement.pause();
        wallpaperVideoElement.removeAttribute('src');
        wallpaperVideoElement.load();
        wallpaperVideoElement.style.display = 'none';
        wallpaperElement.style.backgroundImage = `url("${wallpaperUrl.replace(/"/g, '\\"')}")`;
    }
}

function applySettings(settings) {
    currentSettings = settings;
    document.body.classList.toggle('socials-hidden', !settings.socialsEnabled);
    const colorVariables = {
        textColor:'--text-color', clockColor:'--clock-color', iconBackgroundColor:'--icon-background-color',
        iconColor:'--icon-color', searchBackgroundColor:'--search-background-color',
        searchTextColor:'--search-text-color', searchPlaceholderColor:'--search-placeholder-color'
    };
    for (const [setting, variable] of Object.entries(colorVariables)) document.documentElement.style.setProperty(variable, settings.appearance[setting]);
    for (const [name, element] of Object.entries(widgetElements)) {
        const widget = settings.widgets[name];
        if (!widget) continue;
        element.hidden = !widget.enabled;
        element.dataset.position = widget.position;
        element.style.setProperty('--widget-x', `${widget.offsetX}px`);
        element.style.setProperty('--widget-y', `${widget.offsetY}px`);
    }
    applyWallpaper(settings.wallpaper);
    renderSocials();
    updateMoment();
}

function openSettings() {
    if (globalThis.chrome?.runtime?.openOptionsPage) chrome.runtime.openOptionsPage();
    else location.href = 'options.html';
}

settingsEntry.addEventListener('click', openSettings);
settingsEntry.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        openSettings();
    }
});

const savedFocus = localStorage.getItem('luvinski-focus');
if (savedFocus) focusElement.value = savedFocus;

focusElement.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    const value = focusElement.value.trim();
    if (value) localStorage.setItem('luvinski-focus', value); else localStorage.removeItem('luvinski-focus');
    savedMessage.textContent = value ? 'Focus saved' : 'Focus cleared';
    savedMessage.classList.add('visible');
    focusElement.blur();
});

document.addEventListener('keydown', (event) => {
    if (event.key === '/' && document.activeElement !== queryElement && document.activeElement !== focusElement) {
        event.preventDefault();
        queryElement.focus();
    }
    if (event.key === 'Escape') document.activeElement.blur();
});

BlackThemeStore.read().then(applySettings);
BlackThemeStore.subscribe(applySettings);
updateMoment();

function startClock() {
    clearInterval(clockTimer);
    updateMoment();
    clockTimer = setInterval(updateMoment, 1000);
}
startClock();

document.addEventListener('visibilitychange', () => {
    clearTimeout(hiddenReleaseTimer);
    if (!document.hidden) { startClock(); applyWallpaper(currentSettings.wallpaper); return; }
    clearInterval(clockTimer);
    wallpaperVideoElement.pause();
    hiddenReleaseTimer = setTimeout(() => {
        if (!document.hidden || BlackThemeStore.mediaType(currentSettings.wallpaper) !== 'video') return;
        ++wallpaperVersion;
        wallpaperVideoElement.removeAttribute('src');
        wallpaperVideoElement.load();
        BlackThemeStore.releaseAssetUrl(wallpaperAssetUrl);
        wallpaperAssetUrl = '';
    }, 1500);
});
addEventListener('pagehide', () => {
    clearTimeout(hiddenReleaseTimer);
    clearInterval(clockTimer);
    BlackThemeStore.releaseAssetUrl(wallpaperAssetUrl);
});
